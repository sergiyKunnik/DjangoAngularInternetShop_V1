import { Component, OnInit } from '@angular/core';
import {RegisterService} from "../../services/register.service";
import {Router} from "@angular/router";
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  myform: FormGroup;
  public error_message = '';
  constructor(
    private registerService: RegisterService,
    private router: Router,
  ) { }

  ngOnInit() {
  }

  register(username, password, password1, email){
    this.registerService.RegisterUser(password, password1, username, email).subscribe((data:boolean) =>{
      if(data['status']){
        this.router.navigate(['/login']);
      }else {
        this.error_message = 'Invalid data';
      }
    })
  }

}
