import { Component, OnInit } from '@angular/core';
import {CookieService} from "ngx-cookie-service";
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as CartActions from './../../store/actions/cart.action';
import {CartModel} from "../../models/cart.model";
import {AppState} from "../../store/app.state";
import {CartItemModel} from "../../models/cart_item.model";
import {CartService} from "../../services/cart.service";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart: Observable<CartModel>;
  public cart_list: CartItemModel[];
  public cart_total_price: number;
  public username: string;
  public email: string;

  constructor(
    private store: Store<AppState>,
    private cartService: CartService,
    private cookieService: CookieService,
    private modalService: NgbModal,
  ) {
    this.cart = store.select('cart');
    this.username = this.cookieService.get('username');
  }
  ngOnInit() {
    this.updateValues();
  }

  editCartItem(event, id){
    setTimeout(() =>{
      this.cartService.EditCartItem(id, Number(event.target.value)).subscribe( (data) => {
        this.updateValues();
      });
    }, 2000);
  }
  removeFromCart(cart_item_id: number){
    this.cartService.RemoveFromCart(Number(this.cookieService.get('cart')), cart_item_id).subscribe((data) =>{
      if(data['status']){
        this.updateValues();
      }

    })
  }
  updateValues(){
    this.store.dispatch(new CartActions.GetCart());
      this.cart.subscribe((data: CartModel) => {
        this.cart_list = data.cart_items;
        this.cart_total_price = data.cart_total_price;
      })
  }

  createOrder(desc: string, thankYou){
    this.cartService.CreateOrder(Number(this.cookieService.get('cart')), desc).subscribe( (data) =>{
      if(data['status']){
        this.email = data['email'];
        this.updateValues();
        this.thankYouOpen(thankYou);
      }
    })
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title', windowClass: 'model-class'});
  }
  thankYouOpen(thankYou){
    this.modalService.open(thankYou, {ariaLabelledBy: 'modal-basic-title', windowClass: 'model-class'});
  }


}
