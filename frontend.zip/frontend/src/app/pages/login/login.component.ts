import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {LoginService} from "../../services/login.service";
import {CookieService} from "ngx-cookie-service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public error_message = '';
  constructor(
    private router: Router,
    private loginService: LoginService,
    private cookieService: CookieService,
  ) { }

  ngOnInit() {
  }
  login(username: string, password: string){
    this.loginService.LoginUser(password, username).subscribe((data: any) => {
      if(data.status){
        this.cookieService.deleteAll();
        this.cookieService.set( 'username', data.user.username );
        this.cookieService.set( 'password', data.user.password );
        this.cookieService.set( 'cart', data.cart.cart_id );
        this.router.navigate(['/']);
      }else{
        this.error_message = 'Invalid data';
      }

    })
  }
}
