export const api_url = 'http://127.0.0.1:8000/api/';
export const media_url = 'http://127.0.0.1:8000/';
