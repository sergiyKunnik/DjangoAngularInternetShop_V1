import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import {CategoryModel} from "../../models/category.model";
import * as CategoryActions from './../../store/actions/category.action';
import {AppState} from "../../store/app.state";

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  categories: Observable<CategoryModel[]>;

  constructor(
    private store: Store<AppState>,
    ) {
    this.categories = store.select('category');
  }

  ngOnInit() {
    this.store.dispatch(new CategoryActions.GetCategories());
  }

}
