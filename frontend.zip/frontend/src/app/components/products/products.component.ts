import {Component, Input, OnInit} from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import {ProductModel} from "../../models/product.model";
import * as ProductActions from './../../store/actions/product.action';
import {AppState} from "../../store/app.state";
import {media_url} from "../../api.config";
import { ActivatedRoute, Router } from '@angular/router';
import {NgbModal, NgbActiveModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {LoginService} from "../../services/login.service";
import {CartService} from "../../services/cart.service";
import {CookieService} from "ngx-cookie-service";
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Observable<ProductModel[]>;

  constructor(
    private store: Store<AppState>,
    private route: ActivatedRoute,
    private router: Router,
    private modalService: NgbModal,
    public loginService: LoginService,
    public cartService: CartService,
    public cookieService: CookieService,
    public activeModal: NgbActiveModal,
  ) {
    this.products = store.select('product');
    this.route.params.subscribe(res => {
      if (res.category_id) {
        this.store.dispatch(new ProductActions.GetProductsByCategory(res.category_id));
      } else {
        this.store.dispatch(new ProductActions.GetProducts());
      }
    });
  }

  ngOnInit() {
  }

  getImageUrl(product: ProductModel) {
    return media_url + 'media/' + product.image;
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title', windowClass: 'model-class'});
  }

  addToCart(product_id, qty) {
    if (!this.loginService.IsLoginUser()) {
        this.router.navigate(['/login']);
    }
    let cart_id = Number(this.cookieService.get('cart'));
    this.cartService.AddToCart(cart_id, product_id, Number(qty)).subscribe((data) =>{
      if(data['status']){
        this.activeModal.close('Close click');
      }else{
        alert('Продукт вже в корзині');
      }
    })

  }
}
