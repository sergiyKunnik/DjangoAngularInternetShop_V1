export interface ProductModel {
  id: number,
  title: string,
  text: string,
  price: number,
  image: string,
}
