import {CartItemModel} from "./cart_item.model";

export interface CartModel {
  cart_total_price: number,
  cart_items: CartItemModel[],
  cart_id: number,
}
