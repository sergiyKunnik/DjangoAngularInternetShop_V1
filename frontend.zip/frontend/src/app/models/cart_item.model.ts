export interface CartItemModel {
  qty: number,
  cart_item_total_price: number,
  item_id: number,
  product: {
      product_id: number,
      title: string,
      price: number,
  }

}
