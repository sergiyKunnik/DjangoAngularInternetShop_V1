export interface ProductDetailModel {
  id: number,
  title: string,
  text: string,
  price: number,
  image: string,
}
