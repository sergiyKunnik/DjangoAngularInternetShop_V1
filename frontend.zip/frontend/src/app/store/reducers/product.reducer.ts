import { Action } from '@ngrx/store'
import {ProductModel} from "../../models/product.model";
import * as ProductActions from './../actions/product.action'
import {isUndefined} from "util";

const initialState: ProductModel = {
    id: 105,
    image: "product/images/bookOpen.jpg",
    price: 200,
    title: "Якийсь продукт",
    text: ''
};

export function productReducer(state: ProductModel[] =[initialState], action: ProductActions.Actions) {

    switch(action.type) {
      case ProductActions.GET_PRODUCTS_SUCCESS:
        state = action.payload;
        return state;

        default:
            return state;
    }
}
