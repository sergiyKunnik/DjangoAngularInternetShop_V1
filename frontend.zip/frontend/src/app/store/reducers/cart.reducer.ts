import { Action } from '@ngrx/store'
import {CartModel} from "../../models/cart.model";
import {CartItemModel} from "../../models/cart_item.model";
import * as CartActions from './../actions/cart.action';

// Section 1
const initialState: CartModel = {
    cart_total_price: 0,
    cart_items: [
      {
        qty: 1,
        cart_item_total_price: 0,
        item_id: 1,
        product: {
            product_id: 1,
            title: 'test',
            price: 1,
        }
      }
    ],
    cart_id: 1,
};

// Section 2
export function cartReducer(state = initialState, action: CartActions.Actions) {

    // Section 3
    switch(action.type) {
      case CartActions.GET_CART_SUCCESS:
        state = action.payload;
        return state;
      case CartActions.GET_CART_ITEMS:
        return state.cart_items;
      case CartActions.GET_CART_TOTAL_PRICE:
        return state.cart_total_price;
      default:
          return state;
    }
}
