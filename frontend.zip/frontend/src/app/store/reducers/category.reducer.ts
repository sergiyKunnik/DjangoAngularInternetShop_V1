import { Action } from '@ngrx/store'
import {CategoryModel} from "../../models/category.model";
import * as CategoryActions from './../actions/category.action'

// Section 1
const initialState: CategoryModel = {
    id: 1,
    name: 'default',
};

// Section 2
export function categoryReducer(state: CategoryModel[] = [initialState], action: CategoryActions.Actions) {

    // Section 3
    switch(action.type) {
      case CategoryActions.GET_CATEGORIES_SUCCESS:
        state = action.payload;
        return state;

        default:
            return state;
    }
}
