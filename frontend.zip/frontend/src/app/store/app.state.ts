import {CategoryModel} from "../models/category.model";
import {ProductModel} from "../models/product.model";
import {CartModel} from "../models/cart.model";

export interface AppState {
  readonly category: CategoryModel[];
  readonly product: ProductModel[];
  readonly cart: CartModel,
}
