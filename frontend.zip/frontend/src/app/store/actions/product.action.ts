import { Injectable } from '@angular/core'
import { Action } from '@ngrx/store'
import {ProductModel} from "../../models/product.model";

// Section 2
export const GET_PRODUCTS = 'GET PRODUCTS';
export const GET_PRODUCTS_BY_CATEGORY = 'GET PRODUCTS BY CATEGORY';
export const GET_PRODUCTS_SUCCESS = 'GET PRODUCTS SUCCESS';
export const GET_PRODUCT_DETAIL = 'GET PRODUCT DETAIL';
export const GET_PRODUCT_DETAIL_SUCCESS = 'GET PRODUCT DETAIL SUCCESS';

// Section 3
export class GetProducts implements Action {
    readonly type = GET_PRODUCTS;

    constructor() {}
}

export class GetProductsByCategory implements Action {
    readonly type = GET_PRODUCTS_BY_CATEGORY;

    constructor(public payload: number) {}
}


export class GetProductsSuccess implements Action {
    readonly type = GET_PRODUCTS_SUCCESS;

    constructor(public payload: ProductModel[] ) {}
}

export class GetProductsDetail implements Action {
    readonly type = GET_PRODUCT_DETAIL;

    constructor(public payload: number) {}
}
export class GetProductsDetailSucces implements Action {
    readonly type = GET_PRODUCT_DETAIL_SUCCESS;

    constructor(public payload: number) {}
}

export type Actions = GetProducts | GetProductsSuccess | GetProductsByCategory;
