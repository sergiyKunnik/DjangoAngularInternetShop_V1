import { Injectable } from '@angular/core'
import { Action } from '@ngrx/store'
import {CategoryModel} from "../../models/category.model";

// Section 2
export const GET_CATEGORIES = 'GET CATEGORIES';
export const GET_CATEGORIES_SUCCESS = 'GET CATEGORIES SUCCESS';

// Section 3
export class GetCategories implements Action {
    readonly type = GET_CATEGORIES;

    constructor() {}
}

export class GetCategoriesSuccess implements Action {
    readonly type = GET_CATEGORIES_SUCCESS;

    constructor(public payload: CategoryModel[] ) {}
}

export type Actions = GetCategories | GetCategoriesSuccess;
