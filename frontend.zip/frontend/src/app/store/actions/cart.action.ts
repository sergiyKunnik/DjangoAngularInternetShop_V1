import { Injectable } from '@angular/core'
import { Action } from '@ngrx/store'
import {CartModel} from "../../models/cart.model";
// Section 2
export const GET_CART = 'GET CART';
export const GET_CART_TOTAL_PRICE = 'GET CART TOTAL PRICE';
export const GET_CART_ITEMS = 'GET CART ITEMS';
export const GET_CART_SUCCESS = 'GET CART SUCCESS';
// Section 3

export class GetCart implements Action {
    readonly type = GET_CART;

    constructor() {}
}

export class GetCartTotalPrice implements Action {
    readonly type = GET_CART_TOTAL_PRICE;

    constructor() {}
}

export class GetCartSuccess implements Action {
    readonly type = GET_CART_SUCCESS;

    constructor(public payload: CartModel) {}
}

export class GetCartItems implements Action {
    readonly type = GET_CART_ITEMS;

    constructor() {}
}


export type Actions = GetCart | GetCartSuccess | GetCartTotalPrice | GetCartItems;
