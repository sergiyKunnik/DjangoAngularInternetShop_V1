import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import * as CartActions from './../actions/cart.action';
import {LoginService} from "../../services/login.service";
import {CookieService} from "ngx-cookie-service";

@Injectable()
export class CartEffect {
  constructor(
    private http: HttpClient,
    private actions$: Actions,
    private loginService: LoginService,
    public cookieService: CookieService
  ) {}

  @Effect()
  getCart$: Observable<Action> = this.actions$.pipe(
    ofType(CartActions.GET_CART),
    mergeMap(action =>
      this.loginService.LoginUser(this.cookieService.get('password'), this.cookieService.get('username')).pipe(
        map(data => ({ type: CartActions.GET_CART_SUCCESS, payload: data['cart'] })),
      )
    )
  );

}
