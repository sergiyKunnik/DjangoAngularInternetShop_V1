import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import * as ProductActions from './../actions/product.action';
import {ProductService} from "../../services/product.service";

@Injectable()
export class ProductEffect {
  constructor(
    private http: HttpClient,
    private actions$: Actions,
    private productService: ProductService
  ) {}

  @Effect()
  getProducts$: Observable<Action> = this.actions$.pipe(
    ofType(ProductActions.GET_PRODUCTS),
    mergeMap(action =>
      this.productService.GetProducts().pipe(
        map(data => ({ type: ProductActions.GET_PRODUCTS_SUCCESS, payload: data['products'] })),
      )
    )
  );

  @Effect()
  getProductsByCategory$: Observable<Action> = this.actions$.pipe(
    ofType(ProductActions.GET_PRODUCTS_BY_CATEGORY),
    mergeMap(action =>
      this.productService.GetProductsByCategoryId(action['payload']).pipe(
        map(data => ({ type: ProductActions.GET_PRODUCTS_SUCCESS, payload: data['products'] })),
      )
    )
  );
}
