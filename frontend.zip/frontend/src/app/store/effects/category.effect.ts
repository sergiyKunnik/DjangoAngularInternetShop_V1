import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import * as CategoryActions from './../actions/category.action';
import {CategoryService} from "../../services/category.service";

@Injectable()
export class CategoryEffect {
  constructor(
    private http: HttpClient,
    private actions$: Actions,
    private categoryService: CategoryService
  ) {}
  @Effect()
  getCategories$: Observable<Action> = this.actions$.pipe(
    ofType(CategoryActions.GET_CATEGORIES),
    mergeMap(action =>
      this.categoryService.GetCategories().pipe(
        map(data => ({ type: CategoryActions.GET_CATEGORIES_SUCCESS, payload: data['categories'] })),
      )
    )
  );
}
