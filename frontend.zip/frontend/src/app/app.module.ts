import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbActiveModal, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';

import { RouterModule, Routes } from '@angular/router';

import { EffectsModule } from '@ngrx/effects';
import {CategoryEffect  } from "./store/effects/category.effect";
import {ProductEffect} from "./store/effects/product.effect";
import {CartEffect} from "./store/effects/cart.effect";

import { AppComponent } from './app.component';
import { StoreModule } from '@ngrx/store';
import {categoryReducer} from "./store/reducers/category.reducer";
import {productReducer} from "./store/reducers/product.reducer";
import {cartReducer} from "./store/reducers/cart.reducer";
import { CategoriesComponent } from './components/categories/categories.component';
import {CategoryService} from "./services/category.service";
import {ProductService} from "./services/product.service";
import { ProductsComponent } from './components/products/products.component';
import { HomeComponent } from './pages/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import {RegisterService} from "./services/register.service";
import {LoginService} from "./services/login.service";
import { CookieService } from 'ngx-cookie-service';
import { CartComponent } from './pages/cart/cart.component';
import {CartService} from "./services/cart.service";
import {IfLoginInterceptor} from "./if-login.interceptor";
import { AlertsModule } from 'angular-alert-module';
const appRoutes: Routes = [
  { path: 'category/:category_id', component: HomeComponent },
  { path: '', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'cart',
    component: CartComponent,
    canActivate: [IfLoginInterceptor],

  },
];

@NgModule({
  declarations: [
    AppComponent,
    CategoriesComponent,
    ProductsComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    CartComponent
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      // { enableTracing: true } // <-- debugging purposes only
    ),
    NgbModule.forRoot(),
    BrowserModule,
    HttpClientModule,
    StoreModule.forRoot({
      category: categoryReducer,
      product: productReducer,
      cart: cartReducer,
    }),
    EffectsModule.forRoot([
      CategoryEffect,
      ProductEffect,
      CartEffect,
    ]),
    AlertsModule.forRoot(),
  ],
  providers: [
    CategoryService,
    ProductService,
    RegisterService,
    LoginService,
    CookieService,
    CartService,
    NgbActiveModal,
    IfLoginInterceptor,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
