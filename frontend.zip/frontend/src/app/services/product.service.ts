import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {api_url} from "../api.config";

@Injectable()
export class ProductService {
  constructor(private http: HttpClient) { }

  GetProducts(){
    return this.http.get(api_url+'get_products/');
  }
  GetProductsByCategoryId(category_id){
    return this.http.get(api_url+'get_products_by_category/'+category_id+'/');
  }
  GetProductDetail(product_id){
    return this.http.get(api_url+'product_detail/'+product_id+'/');
  }
}
