import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {api_url} from "../api.config";

@Injectable()
export class RegisterService {
  constructor(private http: HttpClient) { }

  RegisterUser(password, password1, username, email){
    return this.http.post(api_url+'register/', {
      password: password,
      password1: password1,
      username: username,
      email: email
    });
  }
}
