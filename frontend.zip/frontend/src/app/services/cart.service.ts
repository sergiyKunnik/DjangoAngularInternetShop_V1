import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {api_url} from "../api.config";

@Injectable()
export class CartService {
  constructor(private http: HttpClient) { }

  AddToCart(cart_id: number, product_id: number, qty: number){
    let data = {
      cart_id: cart_id,
      product_id: product_id,
      qty: qty,
    };

    return this.http.post(api_url+'add_to_cart/', data);
  }

  EditCartItem(cart_item_id, cart_item_qty) {
    let data = {
      cart_item_id: cart_item_id,
      cart_item_qty: cart_item_qty
    };
    return this.http.post(api_url+'edit_cart/', data);
  }
  RemoveFromCart(cart_id: number, cart_item_id: number){
    return this.http.post(api_url+'remove_from_cart/', {
      cart_id: cart_id,
      cart_item_id: cart_item_id,
    });
  }
  CreateOrder(cart_id: number, desc: string){
    return this.http.post(api_url + 'create_order/', {
      cart_id: cart_id,
      desc: desc,
    })
  }

}
