import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {api_url} from "../api.config";

@Injectable()
export class CategoryService {
  constructor(private http: HttpClient) { }

  GetCategories(){
    return this.http.get(api_url+'get_categories/');
  }
}
