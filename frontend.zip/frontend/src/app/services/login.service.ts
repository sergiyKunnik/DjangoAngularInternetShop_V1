import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {api_url} from "../api.config";
import {CookieService} from "ngx-cookie-service";
import {Router} from "@angular/router";

@Injectable()
export class LoginService {
  constructor(
    private http: HttpClient,
    private cookieService: CookieService,
    private router: Router,
  ) { }

  LoginUser(password, username){

    return this.http.post(api_url+'login/', {
      password: password,
      username: username
    });
  }

  LogoutUser(){
    this.cookieService.deleteAll();
    this.router.navigate(['/'])
  }

  IsLoginUser() {
    if (this.cookieService.get('password') == '' || this.cookieService.get('password') == ''){
      return false;
    }
    return true;
  }


}
